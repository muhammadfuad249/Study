/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Belajar1;

/**
 *
 * @author Legion 5 Pro
 */
public class Pengguna {
    public String name, username, password;
    public boolean role;

    public Pengguna(String name, String username, String password, boolean role) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.role = role;
    }
}
