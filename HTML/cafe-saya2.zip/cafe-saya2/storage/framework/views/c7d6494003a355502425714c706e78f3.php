 
<?php $__env->startSection('content'); ?> 
    <div class="container"> 
        <h2>Menu List</h2> 
        <a href="<?php echo e(route('menus.create')); ?>" class="btn btn-primary">Create New Menu</a> 
        <table class="table table-bordered mt-3"> 
            <thead> 
                <tr> 
                    <th>No.</th> 
                    <th>Id Minuman</th> 
                    <th>Name</th> 
                    <th>Description</th> 
                    <th>Price</th> 
                    <th>Action</th> 
                </tr> 
            </thead> 
            <tbody> 
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr> 
                        <td><?php echo e($index + 1); ?></td> 
                        <td><?php echo e($menu->id); ?></td> 
                        <td><?php echo e($menu->name); ?></td> 
                        <td><?php echo e($menu->description); ?></td> 
                        <td>Rp. <?php echo e(number_format($menu->price, 0, ',', '.')); ?></td> 
                        <td> 
                            <form action="<?php echo e(route('menus.destroy', $menu->id)); ?>" method="POST"> 
                                <a class="btn btn-info" href="<?php echo e(route('menus.show', $menu->id)); ?>">Show</a> 
                                <a class="btn btn-primary" href="<?php echo e(route('menus.edit', $menu->id)); ?>">Edit</a> 
                                <?php echo csrf_field(); ?> 
                                <?php echo method_field('DELETE'); ?> 
                                <button type="submit" class="btn btn-danger">Delete</button> 
                            </form> 
                        </td> 
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </tbody> 
        </table> 
    </div> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\A1_13020230030\Pemrograman Web\cafe-saya2\resources\views/menus/index.blade.php ENDPATH**/ ?>