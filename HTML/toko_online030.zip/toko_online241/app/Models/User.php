<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User 
{ 
    public static function all() 
    { 
        return session('users', []); 
    } 
 
    public static function create($data) 
    { 
        $users = session('users', []); 
        $data['id'] = count($users) + 1; 
        $users[] = $data; 
        session(['users' => $users]); 
        return $data; 
    } 
}