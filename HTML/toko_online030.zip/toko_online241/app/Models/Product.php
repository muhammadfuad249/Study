<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product 
{ 
    public static function all() 
    { 
        return session('product', []); 
    } 
 
    public static function create($data) 
    { 
        $product = session('product', []); 
        $data['id'] = count($product) + 1; 
$product[] = $data; 
session(['product' => $product]); 
return $data; 
} 
}
