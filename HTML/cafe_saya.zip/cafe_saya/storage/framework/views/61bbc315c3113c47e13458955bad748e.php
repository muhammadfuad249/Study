 
 
<?php $__env->startSection('content'); ?> 
    <div class="container"> 
        <h2>Order List</h2> 
        <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-primary">Create New Order</a> 
        <table class="table table-bordered mt-3"> 
            <thead> 
                <tr> 
                    <th>No.</th> 
                    <th>Customer</th> 
                    <th>Menu</th> 
                    <th>Quantity</th> 
                    <th>Total Price</th> 
                    <th>Action</th> 
                </tr> 
            </thead> 
            <tbody> 
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr> 
                        <td><?php echo e($index + 1); ?></td> 
                        <td><?php echo e($order->customer_id); ?></td> 
                        <td><?php echo e($order->menu_id); ?></td> 
                        <td><?php echo e($order->quantity); ?></td> 
                        <td>Rp. <?php echo e(number_format($order->total_price, 0, ',', '.')); ?></td> 
                        <td></td>
                        <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="POST"> 
                                <a class="btn btn-info" href="<?php echo e(route('orders.show', $order->id)); ?>">Show</a> 
                                <a class="btn btn-primary" href="<?php echo e(route('orders.edit', $order->id)); ?>">Edit</a> 
                                <?php echo csrf_field(); ?> 
                                <?php echo method_field('DELETE'); ?> 
                                <button type="submit" class="btn btn-danger">Delete</button> 
                            </form> 
                        </td> 
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </tbody> 
        </table> 
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Code\HTML\cafe_saya\resources\views/orders/index.blade.php ENDPATH**/ ?>