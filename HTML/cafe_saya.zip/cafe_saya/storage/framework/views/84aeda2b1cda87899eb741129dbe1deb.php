 
 
<?php $__env->startSection('content'); ?> 
    <div class="container"> 
        <h2>Customer List</h2> 
        <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-primary">Create New Customer</a> 
        <table class="table table-bordered mt-3"> 
            <thead> 
                <tr> 
                    <th>No.</th> 
                    <th>Id Pembeli</th> 
                    <th>Name</th> 
                    <th>Email</th> 
                    <th>Phone</th> 
                    <th>Action</th> 
                </tr> 
            </thead> 
            <tbody> 
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr> 
                        <td><?php echo e($index + 1); ?></td> 
                        <td><?php echo e($customer->id); ?></td> 
                        <td><?php echo e($customer->name); ?></td> 
                        <td><?php echo e($customer->email); ?></td> 
                        <td><?php echo e($customer->phone); ?></td> 
                        <td> 
                            <form action="<?php echo e(route('customers.destroy', $customer->id)); ?>" method="POST"> 
                                <a class="btn btn-info" href="<?php echo e(route('customers.show', $customer->id)); ?>">Show</a> 
                                <a class="btn btn-primary" href="<?php echo e(route('customers.edit', $customer->id)); ?>">Edit</a> 
                                <?php echo csrf_field(); ?> 
                                <?php echo method_field('DELETE'); ?> 
                                <button type="submit" class="btn btn-danger">Delete</button> 
                            </form> 
                        </td> 
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </tbody> 
        </table> 
    </div> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Code\HTML\cafe_saya\resources\views/customers/index.blade.php ENDPATH**/ ?>