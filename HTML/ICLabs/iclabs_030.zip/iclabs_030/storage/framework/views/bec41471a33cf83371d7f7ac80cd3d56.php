
<?php $__env->startSection('title', 'Profil Perusahaan'); ?> 
 
<?php $__env->startSection('content'); ?> 
    <div class="d-flex align-items-center justify-content-between mb-5"> 
        <div class=" w-50"> 
            <h1 class="fs-1 fw-bold">Laboratorium Terpadu IcLabs Fakultas Ilmu Komputer UMI</h1> 
            <p>Laboratorium fakultas ilmu komputer merupakan fasilitas yang mendukung mahasiswa dalam mengasah keterampilan 
                dan pengetahuan praktis mereka. Melalui laboratorium ini, mahasiswa dapat melakukan praktikum, diri untuk tuntutan industri teknologi informasi yang terus 
                berkembang.</p> 
        </div> 
        <img src="<?php echo e(asset('images/iclabs-logo.jpg')); ?>" alt="Ilustrasi" class=" w-25"> 
    </div> 
 
    <div class="d-flex align-items-center justify-content-between margin-section-between"> 
        <img src="<?php echo e(asset('images/startup1.jpg')); ?>" alt="Fasilitas" class=" w-50 me-5 rounded"> 
        <div class=" w-50"> 
            <h1 class="fs-1 fw-bold">Fasilitas Laboratorium</h1> 
            <p>Laboratorium kami dilengkapi dengan perangkat keras dan perangkat lunak terbaru, memberikan mahasiswa akses 
                ke teknologi mutakhir. Fasilitas ini mencakup 7 laboratorium dan 3 ruang riset yang fasilitasnya sudah 
                sangat mendukung pembelajaran mahasiswa/i.</p> 
        </div> 
    </div> 
 
    <div class="text-center margin-section-between"> 
        <h1 class="fs-1 fw-bold">Denah Lantai 2 FIKOM</h1> 
        <img src="<?php echo e(asset('images/denah lt2.jpeg')); ?>" alt="Fasilitas" class="w-75 rounded "> 
    </div> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Code\HTML\ICLabs\iclabs_030\resources\views/layouts/profile.blade.php ENDPATH**/ ?>