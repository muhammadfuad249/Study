@extends('layouts.app') 
 
@section('title', 'Kontak') 
 
@section('content') 
    <h1 class="text-center">Kontak Kami</h1> 
    <p class="text-center">Anda dapat menghubungi kami melalui email di web resmi kami dan juga melalui sosial media kami.</p> 
@endsection 